let apiKey=<<YOUR FIREBASE API KEY>>;

export default apiKey;