let CloudFunctionURL="https://us-central1-moneymanager-664f7.cloudfunctions.net/";

export default CloudFunctionURL;